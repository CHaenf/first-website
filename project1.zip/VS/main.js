'use strict'

const award = document.querySelector('.award__images');
award.addEventListener('click', ()=>{
    document.querySelector('.award').remove();
})
document.addEventListener('DOMContentLoaded', (event) => {
    const video = document.getElementById('video1r');
    const playButton = document.getElementById('button__video1r');

    playButton.addEventListener('click', () => {
        video.play();
    });
});